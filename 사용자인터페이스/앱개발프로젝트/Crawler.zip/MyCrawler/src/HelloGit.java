
public class HelloGit {
	public static void main(String[] args) {
		System.out.println("hello git");
		System.out.println("hello branch com");
		System.out.println("master test");
	}
}
